#!/bin/sh
printf 'HELLO GREETER\n'
