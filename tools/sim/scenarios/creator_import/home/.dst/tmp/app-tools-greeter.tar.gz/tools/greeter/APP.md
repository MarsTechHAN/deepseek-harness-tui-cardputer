# Greeter

Prints a greeting; used to check app_import.
